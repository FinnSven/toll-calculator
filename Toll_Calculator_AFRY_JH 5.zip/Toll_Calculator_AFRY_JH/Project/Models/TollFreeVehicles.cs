using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Toll_Calculator_AFRY_JH.Project.Models
{
    internal enum TollFreeVehicles
    {
        Motorbike = 0,
        Tractor = 1,
        Emergency = 2,
        Diplomatic = 3, 
        Foreign = 4,
        Military = 5
    } 
}

    
